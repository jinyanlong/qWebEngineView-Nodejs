var os=require("os");
var HomePath=__dirname;
if(os.platform()!="linux"){
    var DataPath=HomePath+"\\data\\";
    var DataBasePath=HomePath+"/database/";
    var ModulesPath=HomePath+"\\modules\\";
    var Objects=HomePath+"\\objects\\";
    var RoutesPath=HomePath+"\\routes\\";
    var DevsPacketsPath=HomePath+"\\devs\\";
    var ViewsPath=RoutesPath+"\\views\\";
    var ServicesPath=HomePath+"\\service\\";
    var configPath=HomePath+"\\config\\";
    var testPath=HomePath+"\\test\\"
    var locationServiceSDKPath=HomePath+"\\services\\locationServiceSDK\\";
    var locationEnginePath=ServicesPath+"\\locationEngine\\";
    var WebSocketPath=HomePath+"\\web-socket-service\\"
}else{
    var DataPath=HomePath+"/data/";
    var DataBasePath=HomePath+"/database/";
    var ModulesPath=HomePath+"/modules/";
    var Objects=HomePath+"/objects/";
    var DevsPacketsPath=HomePath+"/devs/";
    var RoutesPath=HomePath+"/routes/";
    var ViewsPath=RoutesPath+"/views/";
    var ServicesPath=HomePath+"/service/";
    var configPath=HomePath+"/config/"
    var testPath=HomePath+"/test/"
    var locationServiceSDKPath=ServicesPath+"/locationServiceSDK/";
    var locationEnginePath=ServicesPath+"/locationEngine/";
    var WebSocketPath=HomePath+"/web-socket-service/"
}
exports.HomePath=HomePath;
exports.DataPath=DataPath;
exports.DataBasePath=DataBasePath;
exports.ModulesPath=ModulesPath;
exports.Objects=Objects;
exports.DevsPacketsPath=DevsPacketsPath;
exports.RoutesPath=RoutesPath;
exports.ViewsPath=ViewsPath;
exports.ServicesPath=ServicesPath;
exports.configPath=configPath;
exports.testPath=testPath;
exports.locationServiceSDKPath=locationServiceSDKPath;
exports.locationEnginePath=locationEnginePath;
exports.WebSocketPath=WebSocketPath;






