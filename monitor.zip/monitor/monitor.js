var FilePath=require('./file-path')
var Util=require(FilePath.ModulesPath+"util.js")
var ejs = require('ejs');
var express=require('express');
var udp_service=new express();  /*实例化*/
// udp_service.set('view engine','ejs');                 //使用ejs模板引擎   默认找views这个目录
udp_service.engine('html', ejs.__express);
// udp_service.set('views',  'views');                  //注意：这个跟启动文件路径有关系
udp_service.set('view engine', 'html');                 //设置视图引擎
udp_service.use(express.static('static'));              //配置public目录为我们的静态资源目录
var index =require(FilePath.RoutesPath+'index.js')
async function Run(){
    udp_service.use('/',index);
    let port=8889;
    let ip=Util.GetUDPServiceIp()
    udp_service.listen(port,ip);
    console.log("Monitor Service start(","prot:",port,",ip:",ip,")...:")
}
Run();
