﻿var FilePath=require("../file-path.js")
var os=require("os");

class AppData{
    constructor(){
        AppData.LoginState = 0x01;
        if(os.platform()!="linux"){
            AppData.UpgradeFileDir = FilePath.HomePath+"\\..\\";
        }else{
            AppData.UpgradeFileDir = FilePath.HomePath+'/../';
        }
        if(os.platform()!="linux"){
            AppData.UpgradeFileName = FilePath.HomePath+"\\..\\engine-upgrade.zip";
        }else{
            AppData.UpgradeFileName = FilePath.HomePath+'/../engine-upgrade.zip';
        }
        this.Version = 1.1;
        this.EngineState = 0;
    }
    GetUpgradeFileDir(){
        return AppData.UpgradeFileDir;
    }
    GetUpgradeFileName(){
        return AppData.UpgradeFileName;
    }
    GetUnzipAppCmd(){
        let cmd = ""
        if(os.platform()!="linux"){
            cmd = '';
        }else{
            cmd = 'unzip ' + AppData.UpgradeFileName + '-d ' + AppData.UpgradeFileDir;
        }
        return cmd;
    }
    GetDelUpgradFileCmd(){
        let cmd = ""
        if(os.platform()!="linux"){
            cmd = 'del/f/s/q ' + AppData.UpgradeFileName;
        }else{
            cmd = 'rm ' + AppData.UpgradeFileName;
        }
        return cmd;
    }
    GetDelUpgradDirCmd(){
        let cmd = ""
        if(os.platform()!="linux"){
            cmd = 'rd/s/q '+AppData.UpgradeFileDir;
        }else{
            cmd = 'rm -r '+AppData.UpgradeFileDir;
        }
        return cmd;
    }
    GetEngineRebootCmd(){
        let cmd = ""
        if(os.platform()!="linux"){
            cmd = ' ';
        }else{
            cmd = 'reboot';
        }
        return cmd;
    }
    GetVersion(){
        return this.Version;
    }
    GetEngineState(){
        return this.EngineState;
    }
    SetLoginState(state){
        if(state){
            this.EngineState |= AppData.LoginState;
        }else{
            this.EngineState &= (~AppData.LoginState);
        }
    }
    GetLoginState(){
        if(this.EngineState & AppData.LoginState){
            return true;
        }else{
            return false;
        }
    }
}
var appData = new AppData();
exports.AppData = appData;





