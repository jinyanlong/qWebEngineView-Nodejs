var FilePath=require("../../file-path");
var EngineCof = require(FilePath.ModulesPath+'cof-parse.js').EngineCof;
let LocServiceCommonData = require(FilePath.Objects+'common-data').LocServiceCommonData
let WebSocketComData = require(FilePath.Objects+'common-data.js').WebSocketComData
class DataProcess{
    constructor() {
        console.log("create class Util");
        DataProcess.TagDic={};
    }
    PushToCache(tagId,stationId,distance){
        let num =1;
        if(DataProcess.TagDic[tagId]){
            num = DataProcess.TagDic[tagId]['Count']+1;
        }
        DataProcess.TagDic[tagId]={TagId:tagId,StationId:stationId,Distance:distance,Count:num}
    }
    GetTagCache(){
        let tag_list=[];
        for(let item in DataProcess.TagDic){
            tag_list.push(DataProcess.TagDic[item])
        }
        return tag_list;
    }
    SetEngineCof(req,res){
        if(req.body.TenantId!=''){
            EngineCof.SetTenantId(req.body.TenantId);
        }
        if(req.body.EngineId!=''){
            EngineCof.SetEngineId(req.body.EngineId);
        }
        if(req.body.Password!=''){
            EngineCof.SetPassword(req.body.Password);
        }
        if(req.body.RecordUploadUrl!=''){
            EngineCof.SetWebSocUrl(req.body.RecordUploadUrl);
        }
        if(req.body.UdpPort!=''){
            EngineCof.SetMonitorsPort(req.body.UdpPort);
        }
        if(req.body.HoldHours!=''){
            EngineCof.SetHoldHours(req.body.HoldHours);
        }
        if(req.body.AreaIndex != EngineCof.GetAreaIndex()){
            EngineCof.SetAreaIndex(req.body.AreaIndex);
        }
        LocServiceCommonData.RequestRestart();
        WebSocketComData.ResetRestart();
    }
}
var DataProc = new DataProcess();
exports.DataProcess=DataProc;


