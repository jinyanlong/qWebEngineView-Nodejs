var express=require('express');
var router = express.Router();   /*可使用 express.Router 类创建模块化、可挂载的路由句柄*/
var engine=require('./engine.js');

router.get('/',function(req,res){
    res.redirect('/engine')
})

router.use('/engine',engine);
module.exports = router;   /*暴露这个 router模块*/